#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "array_helpers.h"

bool array_is_sorted(int a[], unsigned int length){
    bool allsorted = true;
    
    for(unsigned int i = 0; i<length; i++){
        if (i == length-1){break;}
        allsorted = (a[i] <= a[i+1]) && allsorted;
        }
    return allsorted;
}

unsigned int array_from_file(int array[],
                             unsigned int max_size,
                             const char *filepath) {
        FILE * archivo;
        archivo = fopen(filepath, "r");
        unsigned int size;
        int c;
        
        fscanf(archivo, "%u", &size);
        assert(size < max_size);
        
        for (unsigned int i = 0; i<size; i++){
        c = fscanf(archivo, "%d", &array[i]);
        if (c == EOF){fprintf(stdout, "\nError: Arreglo incompleto.\n"); exit(EXIT_FAILURE);}
        }
        
        fclose(archivo);

    return size;
}

void array_dump(int a[], unsigned int length) {
    printf("[");
    for (unsigned int i=0; i<length; i++){
    printf("%d", a[i]);
    if (i<length-1){printf(", ");}
    }
    printf("]");
}
