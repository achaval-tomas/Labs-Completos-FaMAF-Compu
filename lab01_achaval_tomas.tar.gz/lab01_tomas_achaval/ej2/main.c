/* First, the standard lib includes, alphabetically ordered */
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/* Maximum allowed length of the array */
#define MAX_SIZE 100000

unsigned int array_from_stdin(int array[],
                             unsigned int max_size) {

        fprintf(stdout, "Ingrese el tama�o del arreglo: ");
        unsigned int size;
        fscanf(stdin, "%u", &size);
        
        assert(size < max_size);
        int c;
        
        fprintf(stdout, "\n");
        for (unsigned int i = 0; i<size; i++){
            fprintf(stdout, "Elemento indexado en %u: ", i);
            c = fscanf(stdin, "%d", &array[i]);
            if (c == EOF){fprintf(stdout, "\nError: Arreglo incompleto.\n"); exit(EXIT_FAILURE);}
        }
        fprintf(stdout, "\n");
        
    return size;
}

void array_dump(int a[], unsigned int length) {
    fprintf(stdout, "[");
    for (unsigned int i=0; i<length; i++){
        fprintf(stdout, "%d", a[i]);
        if (i<length-1){printf(", ");}
    }
    fprintf(stdout, "]");
}


int main(void) {

    /* create an array of MAX_SIZE elements */
    int array[MAX_SIZE];
    
    /* parse the file to fill the array and obtain the actual length */
    unsigned int length = array_from_stdin(array, MAX_SIZE);
    
    /*dumping the array*/
    array_dump(array, length);
    
    return EXIT_SUCCESS;
}
