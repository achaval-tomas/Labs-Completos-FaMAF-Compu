#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "stack.h"
 
struct _s_stack {
        stack_elem peak;
        struct _s_stack *next;
};

stack stack_empty(){
    return NULL;
}

stack stack_push(stack s, stack_elem e){
    stack k = malloc(sizeof(struct _s_stack));
    k->peak = e;
    k->next = s;
    return k;
}

stack stack_pop(stack s){
    stack k = s;
    stack p = k->next;
    free(k);
    return p;
}

unsigned int stack_size(stack s){
    unsigned int size = 0u;
    stack p = s;
    while (p!=NULL){
        p = p->next;
        ++size;
    }
    return size;
}

stack_elem stack_top(stack s){
    assert(!stack_is_empty(s));
    return s->peak;    
}

bool stack_is_empty(stack s){
    return (s == NULL);    
}

stack_elem *stack_to_array(stack s){
    stack_elem *a = calloc(stack_size(s), sizeof(stack_elem));
    stack p = s;
    for (unsigned int i = stack_size(s); i>0u; --i){
        a[i-1] = p->peak;
        p = p->next;
        }
    return a;
}

stack stack_destroy(stack s){
    stack p = s;
    while (!stack_is_empty(p)){
        p = stack_pop(p);
        }
    return p;
}

stack load_stack(stack_elem a[], unsigned int length){
    stack ret = stack_empty();
    for(unsigned int i = length; i>0u; --i){
        ret = stack_push(ret, a[i-1]);
    }    
    return ret;
}

