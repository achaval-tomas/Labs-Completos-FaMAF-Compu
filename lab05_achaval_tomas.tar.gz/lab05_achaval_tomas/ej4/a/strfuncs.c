#include "strfuncs.h"

size_t string_length(const char *str){
    if (str == NULL){return 0;}
    size_t length = 0;
    while (str[length]!='\0'){
        ++length;
    }
    return length;
}

char *string_filter(const char *str, char c){
    unsigned int k = 0;
    char *filtered = NULL;
    for (unsigned int i = 0; i<string_length(str); ++i){
        if (str[i] != c){
            filtered = realloc(filtered, k+1);
            filtered[k] = str[i];
            ++k;
        }
    }
    return filtered;
}
