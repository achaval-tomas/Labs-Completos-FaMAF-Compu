#include <stdio.h>
#include <stdbool.h>
#include "string.h"

int main (void){
    string str1 = string_create("Dale dale dale bo.\n");
    string_dump(str1, stdout);    
    string str2 = string_create("Hoy te vinimos a alentar.\n");
    string_dump(str2, stdout);        
    bool order = string_eq(str1, str2);
    if (order) { 
        fprintf(stdout, "\nLas dos frases son iguales.\n");
    }    
    else {
        order = string_less(str1, str2);
        if (order){
            fprintf(stdout, "\nLa primera frase va ANTES alfabeticamente que la segunda.\n");    
        } else {
            fprintf(stdout, "\nLa primera frase va DESPUES alfabeticamente que la segunda.\n");   
        }
    }
    return 0;
}
