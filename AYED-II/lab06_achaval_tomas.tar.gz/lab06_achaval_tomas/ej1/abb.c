#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include "abb.h"

struct _s_abb {
    abb_elem elem;
    struct _s_abb *left;
    struct _s_abb *right;
};

static bool elem_eq(abb_elem a, abb_elem b) {
    return a == b;
}

static bool elem_less(abb_elem a, abb_elem b) {
    return a < b;
}

static bool invrep(abb tree) {
    if (tree == NULL) return true;
    if (!abb_is_empty(tree->right)){
        assert(tree->right->elem >= tree->elem);
    }
    if (!abb_is_empty(tree->left)){
        assert(tree->left->elem < tree->elem);
    }
    
    assert(invrep(tree->left));
    assert(invrep(tree->right));
    return true;
}

abb abb_empty(void) {
    abb tree;
    tree = NULL;
    assert(invrep(tree) && abb_is_empty(tree));
    return tree;
}

abb new_node(abb_elem e){
    abb new_node = malloc(sizeof(struct _s_abb));
    new_node->elem = e;
    new_node->left = abb_empty();
    new_node->right = abb_empty();
    return new_node;
}

abb abb_add(abb tree, abb_elem e) {
    assert(invrep(tree));
    bool b = false;
    abb pTree = tree;

    if (abb_is_empty(tree)){
        tree = new_node(e);
    } else {
        b = elem_less(tree->elem, e);
        if (b && abb_is_empty(tree->right)){
            pTree->right = new_node(e);
        } else if (!b && abb_is_empty(tree->left)){
            pTree->left = new_node(e);
        } else {
            if (b) {pTree = pTree->right;}
            else {pTree = pTree->left;}
        pTree = abb_add(pTree, e);
        }
    }
    assert(invrep(tree) && abb_exists(tree, e));
    return tree;
}

bool abb_is_empty(abb tree) {
    assert(invrep(tree));
    return (tree == NULL);
}

bool abb_exists(abb tree, abb_elem e) {
    assert(invrep(tree));
    bool b = false;
    if (abb_is_empty(tree)){return b;}

    b = (tree->elem==e) || abb_exists(tree->left, e) || abb_exists(tree->right, e);
    
    return b;
}

unsigned int abb_length(abb tree){
    assert(invrep(tree));
    unsigned int length;
    if (abb_is_empty(tree)){
        length = 0;    
    } else {
        length = 1 + abb_length(tree->right) + abb_length(tree->left);   
    }
    
    assert(invrep(tree) && (abb_is_empty(tree) || length > 0));
    return length;
}

abb abb_remove(abb tree, abb_elem e) {
    assert(invrep(tree));
    if (abb_is_empty(tree) || !abb_exists(tree, e)){return tree;}
       
    bool b = elem_less(e, tree->elem);
    abb pointer = tree;
    abb attacher = tree;

    while (!elem_eq(pointer->elem, e)){
        b = elem_less(e, pointer->elem);
        if (b){attacher = pointer; pointer = pointer->left;}
        else {attacher = pointer; pointer = pointer->right;}
    }    // pointer apunta al elemento a eliminar y attacher al anterior.
 
    if (!abb_is_empty(pointer->right)){     // Si hay elementos a la derecha de pointer,
        pointer->elem = abb_min(pointer->right);       // el nuevo valor del nodo que contenia e
        attacher = pointer;
        pointer = pointer->right;                              // sera el minimo de ese subarbol derecho.
        while (!abb_is_empty(pointer->left)){
            attacher = pointer;
            pointer = pointer->left;
        }
        if (attacher->right == pointer){
            attacher->right = pointer->right; 
        } else {
            attacher->left = pointer->right;   //elimino el nodo que contenia al minimo del subarbol derecho.
        }
        free(pointer);
    } else if (!abb_is_empty(pointer->left)){     // repito pero para el subarbol izquierdo.
        pointer->elem = abb_max(pointer->left);         // reemplazando el nodo por el maximo de ese subarbol.
        attacher = pointer;
        pointer = pointer->left;
        while (!abb_is_empty(pointer->right)){
            attacher = pointer;
            pointer = pointer->right;
        }
        if (attacher->left == pointer){
            attacher->left = pointer->left; 
        } else {
            attacher->right = pointer->left;   //elimino el nodo que contenia al minimo del subarbol derecho.
        }
        free(pointer);    
    } else {
        if (b) {attacher->left = NULL;}
        else {attacher->right = NULL;}
        free(pointer);}
    
    assert(invrep(tree) && !abb_exists(tree, e));
    return tree;
}


abb_elem abb_root(abb tree) {
    abb_elem root;
    assert(invrep(tree) && !abb_is_empty(tree));
    root = tree->elem;
    assert(abb_exists(tree, root));
    return root;
}

abb_elem abb_max(abb tree) {
    abb_elem max_e;
    assert(invrep(tree) && !abb_is_empty(tree));
    abb pTree = tree;
    while (!abb_is_empty(pTree->right)){
        pTree = pTree->right;
    }
    max_e = pTree->elem;
    assert(invrep(tree) && abb_exists(tree, max_e));
    return max_e;
}

abb_elem abb_min(abb tree) {
    abb_elem min_e = NULL;
    assert(invrep(tree) && !abb_is_empty(tree));
    abb pTree = tree;
    while (!abb_is_empty(pTree->left)){
        pTree = pTree->left;
    }
    min_e = pTree->elem;
    assert(invrep(tree) && abb_exists(tree, min_e));
    return min_e;
}

void abb_dump(abb tree) {
    assert(invrep(tree));
    if (tree != NULL) {
        printf("%d ", tree->elem);
        abb_dump(tree->left);
        abb_dump(tree->right);
    }
}

abb abb_destroy(abb tree) {
    assert(invrep(tree));
    if (!abb_is_empty(tree)){
    abb_destroy(tree->left);
    abb_destroy(tree->right);
    free(tree);
    }
    tree = NULL;
    assert(tree == NULL);
    return tree;
}

