#include <assert.h>
#include <stdlib.h>
#include "dict.h"
#include "key_value.h"

struct _node_t {
    dict_t left;
    dict_t right;
    key_t key;
    value_t value;
};

static bool invrep(dict_t d) {
    if (d == NULL){return true;
    } else {
    if (d->right != NULL){
        assert(!key_less(d->right->key, d->key));
        assert(invrep(d->right));
    }
    if (d->left != NULL){
        assert(key_less(d->left->key, d->key));
        assert(invrep(d->left));
    }
    }
    return true;
}

dict_t dict_empty(void) {
    dict_t dict = NULL;
    return dict;
}


dict_t new_node(key_t word, value_t def){
    dict_t new_node = malloc(sizeof(struct _node_t));
    new_node->key = word;
    new_node->value = def;
    new_node->left = NULL;
    new_node->right = NULL;
    return new_node;
}

dict_t dict_add(dict_t dict, key_t word, value_t def) {
    assert(invrep(dict));
    bool b = false;
    dict_t pDict = dict;

    if (dict == NULL){
        return new_node(word, def);
    } else {
        b = key_less(dict->key, word);
        if (b && dict->right == NULL){
            pDict->right = new_node(word, def);
        } else if (!b && dict->left == NULL){
            pDict->left = new_node(word, def);
        } else {
            if (b) {pDict = pDict->right;}
            else {pDict = pDict->left;}
        pDict = dict_add(pDict, word, def);
        }
    }
    assert(invrep(dict) && dict_exists(dict, word));
    return dict;
}

value_t dict_search(dict_t dict, key_t word) {
    key_t def=NULL;
    if (dict_exists(dict, word)){
    dict_t pointer = dict;
    bool b = false;
    while (!key_eq(pointer->key, word)){
        b = key_less(word, pointer->key);
        if (b){pointer = pointer->left;}
        else {pointer = pointer->right;}
    }   def = pointer->value;
    }
    return def;
}

bool dict_exists(dict_t dict, key_t word) {
    assert(invrep(dict));
    bool b = false;
    if (dict != NULL){
    b = key_eq(dict->key, word) || dict_exists(dict->left, word) || dict_exists(dict->right, word);
    }
    return b;
}

unsigned int dict_length(dict_t dict) {
    assert(invrep(dict));
    unsigned int length = 0u;
    if (dict != NULL){
        length = 1u + dict_length(dict->right) + dict_length(dict->left);   
    }
    
    assert(invrep(dict) && (dict==NULL || length > 0));
    return length;
}

dict_t dict_remove(dict_t dict, key_t word) {
    assert(invrep(dict));
    if (dict==NULL || !dict_exists(dict, word)){return dict;}
    if (key_eq(dict->key, word)){
        dict->key = key_destroy(dict->key);
        dict->value = value_destroy(dict->value);
        free(dict);
        return NULL;
    }
    bool b = key_less(word, dict->key);
    dict_t pointer = dict;
    dict_t attacher = dict;

    while (!key_eq(pointer->key, word)){
        b = key_less(word, pointer->key);
        if (b){attacher = pointer; pointer = pointer->left;}
        else {attacher = pointer; pointer = pointer->right;}
    }    // pointer apunta al elemento a eliminar y attacher al anterior.
 
    if (pointer->right != NULL){                // Si no esta vacio el subdiccionario de la derecha,
        dict_t node = dict_min(pointer->right);      // reemplazo mi palabra por la menor de dicho subdiccionario.
        pointer->key = node->key;
        pointer->value = node->value;
        attacher = pointer;
        pointer = pointer->right; 
        while (pointer->left != NULL){
            attacher = pointer;
            pointer = pointer->left;
        }
        if (attacher->right == pointer){
            attacher->right = pointer->right; 
        } else {
            attacher->left = pointer->right;
        }
        free(pointer);
    } else if (pointer->left != NULL){            // Si el subdiccionario de la derecha esta vacio,
        dict_t node = dict_max(pointer->left);         // pero el de la izquierda no, entonces reemplazo mi palabra
        pointer->key = node->key;                         // por la mayor de dicho subdiccionario.
        pointer->value = node->value;
        attacher = pointer;
        pointer = pointer->left;
        while (pointer->right != NULL){
            attacher = pointer;
            pointer = pointer->right;
        }
        if (attacher->left == pointer){
            attacher->left = pointer->left; 
        } else {
            attacher->right = pointer->left;
        }
        key_destroy(pointer->key);
        value_destroy(pointer->value);
        free(pointer);    
    } else {
        if (b) {attacher->left = NULL;}
        else {attacher->right = NULL;}
        pointer->key = key_destroy(pointer->key);
        pointer->value = value_destroy(pointer->value);
        free(pointer);
    }
    
    assert(invrep(dict) && !dict_exists(dict, word));
    return dict;
}

dict_t dict_remove_all(dict_t dict) {
    assert(invrep(dict));
    if(dict != NULL){
        if(dict->left != NULL){
            dict->left = dict_remove_all(dict->left);
        }
        if(dict->right != NULL){
            dict->right = dict_remove_all(dict->right);
        }
        dict->key = key_destroy(dict->key);
        dict->value = value_destroy(dict->value);
        free(dict);
        dict = NULL;
    }
    assert(invrep(dict) && dict_length(dict) == 0);
    return dict;
}

void dict_dump(dict_t dict, FILE *file) {
    assert(invrep(dict));
    if (dict != NULL){
        dict_dump(dict->left, file);
        key_dump(dict->key, file);
        fprintf(stdout, ": ");
        value_dump(dict->value, file);
        fprintf(stdout, "\n");
        dict_dump(dict->right, file);
    }
}

dict_t dict_destroy(dict_t dict) {
    assert(invrep(dict));
    if (dict != NULL){
        dict_destroy(dict->left);
        dict_destroy(dict->right);
        key_destroy(dict->key);
        value_destroy(dict->value);
        free(dict);
    }
    dict = NULL;
    assert(dict == NULL);
    return dict;
}

/* EXTRA FUNCTIONS */
/* Returns the last alphabetically ordered word and def form a dict*/
dict_t dict_max(dict_t dict){
    assert(dict != NULL);
    dict_t pointer = dict;
    while (pointer->right != NULL){
        pointer = pointer->right;
    }
    dict_t node = new_node(pointer->key, pointer->value);
    return node;
}

/* Returns the first alphabetically ordered word and def from a dict*/
dict_t dict_min(dict_t dict){
    assert(dict != NULL);
    dict_t pointer = dict;
    while (pointer->left != NULL){
        pointer = pointer->left;
    }
    dict_t node = new_node(pointer->key, pointer->value);
    return node;
}










