#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "sort_helpers.h"

bool goes_before(int x, int y){
    return (abs(x)<=abs(y));
    }
/* Abstract total order for sorting algorithms */

bool array_is_sorted(int a[], unsigned int length){
    bool allSorted = true;
    for (unsigned int i = 0; i<length-1;i++){
        allSorted = goes_before(a[i], a[i+1]) && allSorted;
        }
    return allSorted;
    }
/* Checks if the array 'a' is in ascending order */

void swap(int a[], unsigned int i, unsigned int j){
    int c = a[j];
    a[j] = a[i];
    a[i] = c;
    }
/* Exchanges elements of array 'a' in the given positions 'i' and 'j'
   Array remains the same if the two positions are the same
*/
