#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_helpers.h"
#include "sort_helpers.h"
#include "sort.h"


static unsigned int partition(int a[], unsigned int izq, unsigned int der) {
    
    unsigned int pivElem, leftSide;
    pivElem = a[der-1];
    leftSide = izq;
    
    for (unsigned int i = izq; i<der-1; i++){
        if (goes_before(a[i], pivElem)){swap(a, i, leftSide); leftSide++;}
        }
    swap(a, der-1, leftSide);
    return leftSide;
    
    /* Permutes elements of a[izq..der] and returns pivot such that:
     - izq <= pivot <= der
     - elements in a[izq,pivot) all 'go_before' (according to function goes_before) a[pivot]
     - a[pivot] 'goes_before' all the elements in a(pivot,der]
    */
}

static void quick_sort_rec(int a[], unsigned int izq, unsigned int der) {
    unsigned int piv;
    if (izq < der) {
        piv = partition(a, izq, der);
        quick_sort_rec(a, izq, piv);
        quick_sort_rec(a, piv+1, der);
        }

}

void quick_sort(int a[], unsigned int length) {
    quick_sort_rec(a, 0, length);
}

