#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include "array_helpers.h"
#include "sort_helpers.h"
#include "sort.h"
#include "fixstring.h"


static unsigned int partition(fixstring a[], unsigned int izq, unsigned int der) {
    fixstring pivElem;
    unsigned int leftSide;
    fstring_set(pivElem, a[der-1]);
    leftSide = izq;
    
    for (unsigned int i = izq; i<der-1; i++){
        if (goes_before(a[i], pivElem)){swap(a, i, leftSide); leftSide++;}
        }
    swap(a, der-1, leftSide);
    return leftSide;
}

static void quick_sort_rec(fixstring a[], unsigned int izq, unsigned int der) {
    unsigned int piv;
    if (izq < der) {
        piv = partition(a, izq, der);
        quick_sort_rec(a, izq, piv);
        quick_sort_rec(a, piv+1, der);
        }
}

void quick_sort(fixstring a[], unsigned int length) {
    quick_sort_rec(a, 0u, length);
}


