#include <assert.h>
#include <stdbool.h>
#include <stdio.h>

#include "array_helpers.h"
#include "sort_helpers.h"
#include "sort.h"


static void quick_sort_rec(int a[], unsigned int izq, unsigned int der) {
    unsigned int piv;
    if (izq < der) {
        piv = partition(a, izq, der);
        quick_sort_rec(a, izq, piv);
        quick_sort_rec(a, piv+1, der);
        }
    /* no implementes partition, ya esta implementado en sort_helpers.o
       (no se puede leer, pero en sort_helpers.h vas a encontrar informacion
        para saber como usarlo)
    */
}

void quick_sort(int a[], unsigned int length) {
    quick_sort_rec(a, 0u, length); // modificado para que pase la longitud total del arreglo.
}

