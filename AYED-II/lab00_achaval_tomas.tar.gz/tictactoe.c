#include <stdlib.h>  /* exit() y EXIT_FAILURE */
#include <stdio.h>   /* printf(), scanf()     */
#include <stdbool.h> /* Tipo bool             */

#include <assert.h>  /* assert() */

#define DIM 5 /* Esta implementacion del c�digo funciona para cualquier tablero DIMxDIM solo cambiando este valor*/
#define CELL_MAX (DIM * DIM - 1)

void print_sep(int length) {
    printf("\t ");
    for (int i=0; i < length;i++) printf("................");
    printf("\n");

}

void print_board(char board[DIM][DIM])
{
    int cell = 0;

    print_sep(DIM);
    for (int row = 0; row < DIM; ++row) {
        for (int column = 0; column < DIM; ++column) {
            printf("\t | %d: %c ", cell, board[row][column]);
            ++cell;
        }
        printf("\t | \n");
        print_sep(DIM);
    }
}

char get_winner(char board[DIM][DIM])
{
    char winner;
    bool winD1 = true;
    bool winD2 = true;
    char winner2 = board[0][0];
    char winner3 = board[DIM-1][0];    // Preestablezco chars de referencia importantes.
    
    for (int i = 0; i<DIM; i++){
        bool winF = true;
        bool winC = true;
        winner = board[i][i];  // Establece como referencia a un numero para analizar su fila y columna.
            
            for (int j = 0; j<DIM; j++){
                winF = (board[i][j] == winner) && winF;  // Analiza una fila.
                winC = (board[j][i] == winner) && winC;  // Analiza una columna.
            }
            
        if (winF || winC) return winner;   // Si hay un ganador por filas o columnas, lo devuelve.
        
        winD1 = (board[i][i] == winner2) && winD1;            // Analiza diagonal y = -x
        winD2 = (board[i][DIM-i-1] == winner3) && winD2;      // Analiza diagonal y = x
    }
    
    if (winD1) return winner2;
    if (winD2) return winner3;
    
    return '-'; 
}

bool has_free_cell(char board[DIM][DIM])
{

    for (int i = 0; i<DIM; i++){
        for (int j = 0; j<DIM; j++){
            if (board[i][j] == '-'){
                return true;
            }
        }
    }
    return false;
}

int main(void)
{
    printf("TicTacToe\n");
    
    char board[DIM][DIM];
    for (int i = 0; i<DIM; i++){
        for (int j = 0; j<DIM; j++){
            board[i][j] = '-';
    }
    }

    char turn = 'X';
    char winner = '-';
    int cell = 0;
    while (winner == '-' && has_free_cell(board)) {
        print_board(board);
        printf("\nTurno %c - Elija posición (número del 0 al %d): ", turn,
               CELL_MAX);
        int scanf_result = scanf("%d", &cell);
        if (scanf_result <= 0) {
            printf("Error al leer un número desde teclado\n");
            exit(EXIT_FAILURE);
        }
        if (cell >= 0 && cell <= CELL_MAX) {
            int row = cell / DIM;
            int colum = cell % DIM;
            if (board[row][colum] == '-') {
                board[row][colum] = turn;
                turn = turn == 'X' ? 'O' : 'X';
                winner = get_winner(board);
            } else {
                printf("\nCelda ocupada!\n");
            }
        } else {
            printf("\nCelda inválida!\n");
        }
    }
    print_board(board);
    if (winner == '-') {
        printf("Empate!\n");
    } else {
        printf("Ganó %c\n", winner);
    }
    return 0;
}
