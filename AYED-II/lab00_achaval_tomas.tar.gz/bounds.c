#include <stdio.h>
#include <stdbool.h>

typedef struct bound_data {
bool is_upperbound;
bool is_lowerbound;
bool exists;
unsigned int where;
} info;

info check_bound(int value, int arr[], unsigned int length){
      info result = {true, true, false, 0};
      
      for (unsigned int i = 0; i<length; i++){
        result.is_upperbound = result.is_upperbound && (arr[i] <= value);
        result.is_lowerbound = result.is_lowerbound && (arr[i] >= value);

        if (arr[i] == value && !result.exist){
        result.exists = true;
        result.where = i;
        }
      }   
    return result;
}

int main (void) {
    int value;
    int length;
    printf("Ingrese el tamaño del arreglo: ");
    scanf("%d", &length);
    int a[length];
    
    for (int i = 0; i<length; i++){
        printf("Ingrese el elemento %d del arreglo: ", i);
        scanf("%d", &a[i]);    
    }
    
    printf("Ingrese un valor para verificar: ");
    scanf("%d", &value);
    
    info result = check_bound(value, a, length);
    
    if (result.is_upperbound && result.exists){
        printf("\nTu valor es el maximo y se encuentra en la posicion %d\n", result.where);
    } else if (result.is_upperbound){
        printf("\nTu valor es cota superior pero no esta en el arreglo\n");
    } else if (result.is_lowerbound && result.exists){
        printf("\nTu valor es el minimo y se encuentra en la posicion %d\n", result.where);
    } else if (result.is_lowerbound){
        printf("\nTu valor es cota inferior pero no esta en el arreglo\n");
    } else {
        printf("\nTu valor se encuentra dentro de los limites del arreglo (no es cota)\n");
    };
    
    
    return 0;
}
