#ifndef _utils
#define _utils
#include "array_helpers.h"

int minimo (int a, int b);

int menor_temperatura_minima(WeatherTable a);

void mayor_temperatura_maxima(WeatherTable a, int b[]);

void meses_de_mayor_precipitaciones(WeatherTable a, month_t s[]);

#endif
