#include "weather_utils.h"

int minimo (int a, int b){
    if (a<b){return a;}
    return b;
}

int maximo (int a, int b){
    if (a>b){return a;}
    return b;
}

int menor_temperatura_minima(WeatherTable a){

    int menTempMin = a[0][0][0]._min_temp;
    for(unsigned int i = 0; i<YEARS; ++i){
        for(unsigned int j = 0; j<MONTHS; ++j){
            for(unsigned int k = 0; k<DAYS; ++k){
                menTempMin = minimo(menTempMin, a[i][j][k]._min_temp); 
            }
        }
   }
   return menTempMin;
}

void mayor_temperatura_maxima(WeatherTable a, int b[YEARS]){

    int mayTemp = a[0][0][0]._max_temp;
    for(unsigned int i = 0; i<YEARS; ++i){
        mayTemp = a[i][0][0]._max_temp;
        for(unsigned int j = 0; j<MONTHS; ++j){
            for(unsigned int k = 0; k<DAYS; ++k){
                mayTemp = maximo(mayTemp, a[i][j][k]._max_temp); 
            }
        }
        b[i] = mayTemp;
   }
}

void meses_de_mayor_precipitaciones(WeatherTable a, month_t s[YEARS]){
    for(unsigned int i = 0; i<YEARS; ++i){
        month_t mes = january;
        unsigned int mas_prec = 0;
        for(unsigned int j = 0; j<MONTHS; ++j){
           unsigned int totalPrec = 0;
            for(unsigned int k = 0; k<DAYS; ++k){
                totalPrec += a[i][j][k]._rainfall; 
            }
        if (totalPrec > mas_prec){
        mas_prec = totalPrec;
        mes = j;
        }
        }
        s[i] = mes;
   }

}

