#include <stdlib.h>
#include <stdio.h>

void absolute(int x, int *y) {
    if (x >= 0) {
        *y = x;
    } else {
        *y=-x;
    }
}

int main(void) {
    int a=0, res=0;  // No modificar esta declaración
    int *p = &res;
    a = -10;
    absolute(a, p);
    fprintf(stdout, "%d", res);

    return EXIT_SUCCESS;
}

/*
 El par�metro int *i en absolute() es de tipo out.
 C tiene disponibles par�metros in y out. No in/out (a menos que se utilicen punteros y arreglos, los
 cuales pueden ser vistos como in/out).



*/
