#include <stdlib.h>
#include <stdio.h>

void absolute(int x, int y) {
    if (x >= 0) {
        y = x;
    } else {
        y=-x;
    }
}

int main(void) {
    int a=0, res=0;
    a = -10;
    absolute(a, res);
    fprintf(stdout, "%d", res);
    return EXIT_SUCCESS;
}

/* Al ejecutar el codigo se muestra el valor 0, el cual no coincide con el
valor que tendria el resultado en el lenguaje del te�rico. */
