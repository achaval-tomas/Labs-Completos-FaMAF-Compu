#include <stdlib.h>
#include <stdio.h>

#define MAX_SIZE 1000

static void dump(char a[], unsigned int length) {
    printf("\"");
    for (unsigned int j=0u; j < length; j++) {
        printf("%c", a[j]);
    }
    printf("\"");
    printf("\n\n");
}

char *parse_filepath(int argc, char *argv[]) {
    if (argc<2){
        fprintf(stderr, "Cantidad incorrecta de argumentos\n");
        exit(EXIT_FAILURE);
        }
    return argv[1];
}

unsigned int data_from_file(const char *path, unsigned int indexes[], char letters[], unsigned int max_size){
    FILE * archivo;
    archivo = fopen(path, "r");
    
    unsigned int i = 0; 
    while (i<max_size && !feof(archivo)){
        fscanf(archivo, "%d * ", &indexes[i]);
        fscanf(archivo, "-> *%c* ", &letters[i]);
        ++i;
        }
    
    fclose(archivo);
    return i;
}

void copyIt(char a[], char b[], unsigned int length){
    for (unsigned int i = 0; i<length; i++){
        b[i] = a[i];
        }
    }

void sortIt(char letters[], unsigned int indexes[], unsigned int length){
    char copy[length];
    copyIt(letters, copy, length);
    for(unsigned int i = 0; i<length; ++i){
        if(indexes[i]>=length){
            fprintf(stderr, "SORTING FAILED: Incorrect indexation.\n");
            exit(EXIT_FAILURE);}
        letters[indexes[i]] = copy[i];
        }
    }


int main(int argc, char *argv[]) {
    char *filepath = NULL;
    filepath = parse_filepath(argc, argv);
    
    unsigned int indexes[MAX_SIZE];
    char letters[MAX_SIZE];
    char sorted[MAX_SIZE];
    unsigned int length=0; 
    
    length = data_from_file(filepath, indexes, letters, MAX_SIZE);
    copyIt(letters, sorted, length);
    sortIt(sorted, indexes, length);
    
    dump(letters, length);
    dump(sorted, length);
    
    return EXIT_SUCCESS;
}

