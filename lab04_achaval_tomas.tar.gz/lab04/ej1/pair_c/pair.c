#include <stdlib.h>
#include <stdio.h>
#include "pair.h"

struct s_pair_t {
    int fst;
    int snd;
};

pair_t pair_new(int x, int y){
    pair_t k;
    k = malloc(sizeof(struct s_pair_t));
    k->fst = x;
    k->snd = y;
    return k;
    }

int pair_first(pair_t p){
    return p->fst;
    }

int pair_second(pair_t p){
    return p->snd;
    }

pair_t pair_swapped(pair_t p){
    pair_t k;
    k = malloc(sizeof(struct s_pair_t));
    k->fst = p->snd;
    k->snd = p->fst;
    return k;
    }

pair_t pair_destroy(pair_t p){
    free(p);
    return NULL;
    }
    

