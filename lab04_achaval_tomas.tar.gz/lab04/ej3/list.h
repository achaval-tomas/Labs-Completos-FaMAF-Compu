#ifndef LISTAS
#define LISTAS
#include <assert.h>
#include <stdbool.h>

typedef int list_elem;

typedef struct node* list;

list empty(void);
/*
Devuelve una lista vacia.
*/

list addl(list l, list_elem e);
/*
Agrega un elemento al inicio de la lista.
*/

list addr(list l, list_elem e);
/*
Agrega un elemento al final de la lista.
*/

bool is_empty(list l);
/*
Determina si una lista es vacia.
*/

list_elem index(list l, unsigned int i);
/*
PRE: length(l) >= i
Devuelve el elemento en la posicion i de la lista.
*/

list tail(list l);
/*
PRE: not is_empty(l)
Elimina el primer elemento de la lista.
*/

list_elem head(list l);
/*
PRE: not is_empty(l)
Devuelve el primer elemento de la lista.
*/

list take(list l, unsigned int n);
/*
Deja los primeros n elementos de l, eliminando al resto.
*/

list drop(list l, unsigned int n);
/*
Elimina los primeros n elementos de l.
*/

list concat(list l1, list l2);
/*
Agrega al final de l1 todos los elementos de l2
en el mismo orden
*/

list copy_list(list l);
/*
Devuelve una copia de l.
*/

unsigned int list_length(list l);
/*
Devuelve la cantidad de elementos de la lista l.
*/

void destroy(list l);
/*
Libera memoria en caso de que sea necesario.
*/

#endif
