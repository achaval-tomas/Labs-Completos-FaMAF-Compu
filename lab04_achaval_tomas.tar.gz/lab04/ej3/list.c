#include <stdio.h>
#include <stdlib.h>
#include "list.h"

struct node{
    list_elem elem;
    struct node *next;
};
    
list empty(void){
    list l = NULL;
    return l;
}

list addl(list l, list_elem e){
    struct node *k = malloc(sizeof(struct node));
    k->elem = e;
    k->next = l;
    return k;
}

list addr(list l, list_elem e){
    struct node *last = malloc(sizeof(struct node));
    last->elem = e;
    last->next = NULL;
    if (l == NULL){
        return last;
        } else {
            struct node *p;
            p = l;
            while (p->next != NULL){
                p = p->next;
            } 
            p->next = last;
        }
    return l;
}

bool is_empty(list l){
    return (l==NULL);
}

list_elem index(list l, unsigned int desiredIndex){
    assert(list_length(l) >= desiredIndex);
    struct node *p = l;
    unsigned int currentIndex = 1u;
    while (currentIndex<desiredIndex){
        p = p->next;
        ++currentIndex;
    }
    return (p->elem);
}

list tail(list l){
    assert(!is_empty(l));
    struct node *p;
    p = l->next;
    free(l);
    return p;
}

list_elem head(list l){
    assert(!is_empty(l));
    return (l->elem);
}

list take(list l, unsigned int n){
    list took = empty();
    list aux = l;
    unsigned int i = 0u;
    while (i<n && l!=NULL){
        took = addr(took, head(aux));
        aux = tail(aux);
        ++i;
    }
    destroy(aux);
    destroy(l);
    return took;
}

list drop(list l, unsigned int n){
    list drops = l;
    unsigned int i = 0u;
    while (i<n && l!=NULL){
        drops = tail(drops);
        ++i;
    }
    destroy(l);
    return drops;
}

list concat(list l1, list l2){
    struct node *p;
    p = l1;
    while (p->next != NULL){
        p = p->next;
    }
    p->next = l2;
    return l1;
}

list copy_list(list l){
    list copy = empty();
    struct node *p = l;
    while (p != NULL){
        copy = addl(copy, p->elem);
        p = p->next;
    }
    return copy;
}

unsigned int list_length(list l){
    struct node *p = copy_list(l);
    unsigned int length = 0u;
    if (p == NULL){
        length = 0u;
    } else {
    while (p != NULL){
        p = tail(p);
        ++length;
    }
    }
    return length;
}

void destroy(list l){
    for(unsigned int i = 0u; i<list_length(l); ++i){
        l = tail(l);    
    }
}
